#include "stdafx.h"

#include <iostream>
#include "wavfile.h"
#include <cstdlib>
#include <cstring>
#include <set>

using namespace std;



WAVE::WAVE(){
}

WAVE::~WAVE(){
	for (int i = 0; i < wave_format.numChannels; ++i)
		delete[] buffer[i];
}

bool loadWavFile(char* filename, WAVE& output_wave)
{

	//Local Declarations
	FILE* soundFile = NULL;
	soundFile = fopen(filename, "rb");
	if (!soundFile)
	{
		printf("ERROR loading Sound!\n");
		return false;
	}

	// Read in the first chunk into the struct
	fread(&output_wave.riff_header, sizeof(output_wave.riff_header), 1, soundFile);

	//check for RIFF and WAVE tag in memeory
	if ((output_wave.riff_header.chunkID[0] != 'R' ||
		output_wave.riff_header.chunkID[1] != 'I' ||
		output_wave.riff_header.chunkID[2] != 'F' ||
		output_wave.riff_header.chunkID[3] != 'F') ||
		(output_wave.riff_header.format[0] != 'W' ||
		output_wave.riff_header.format[1] != 'A' ||
		output_wave.riff_header.format[2] != 'V' ||
		output_wave.riff_header.format[3] != 'E'))
		printf("Invalid RIFF or WAVE Header");

	//Read in the 2nd chunk for the wave info
	fread(&output_wave.wave_format, sizeof(output_wave.wave_format), 1, soundFile);
	//check for fmt tag in memory
	if (output_wave.wave_format.subChunkID[0] != 'f' ||
		output_wave.wave_format.subChunkID[1] != 'm' ||
		output_wave.wave_format.subChunkID[2] != 't' ||
		output_wave.wave_format.subChunkID[3] != ' ')
		printf("Invalid Wave Format");

	//check for extra parameters;
	if (output_wave.wave_format.subChunkSize > 16)
		fseek(soundFile, sizeof(short), SEEK_CUR);

	//Read in the the last byte of data before the sound file
	fread(&output_wave.wave_data, sizeof(output_wave.wave_data), 1, soundFile);
	//check for data tag in memory
	if (output_wave.wave_data.subChunkID[0] != 'd' ||
		output_wave.wave_data.subChunkID[1] != 'a' ||
		output_wave.wave_data.subChunkID[2] != 't' ||
		output_wave.wave_data.subChunkID[3] != 'a')
		throw ("Invalid data header");

	//Allocate memory for data
	int bit_depth = output_wave.wave_format.bitsPerSample / 8;
	output_wave.buffer = new float*[output_wave.wave_format.numChannels];
	short* wav_buffer = new short[output_wave.wave_data.subChunk2Size / bit_depth];
	// Read in the sound data into the soundData variable
	//if (!fread(wav_buffer, output_wave.wave_data.subChunk2Size, 1, soundFile))
	//	throw ("error loading WAVE data into struct!");
	if (!fread(wav_buffer, 2, output_wave.wave_data.subChunk2Size / bit_depth, soundFile))
		throw ("error loading WAVE data into struct!");


	//Separate the buffer into channels
	int n = output_wave.wave_data.subChunk2Size;
	int nchannels = output_wave.wave_format.numChannels;
	int channel_size = n / (bit_depth * output_wave.wave_format.numChannels);
	for (int i = 0; i < output_wave.wave_format.numChannels; ++i){
		output_wave.buffer[i] = new float[channel_size];
		for (int j = 0; j < channel_size; ++j){
			float f = wav_buffer[i + j * nchannels] / float(INT16_MAX);
			/*if (f > 1)
				f = 1;
			if (f < -1)
				f = -1;*/
			output_wave.buffer[i][j] = f;
		}
	}
	//Now we set the variables that we passed in with the

	//data from the structs
	delete[] wav_buffer;
	fclose(soundFile);
	return true;
}