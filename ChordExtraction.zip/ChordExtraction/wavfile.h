#define INT16_MIN -32768 
#define INT16_MAX 32767
#include <cstring>


#define MIN(a, b) (a < b) ? a : b
#define MAX(a, b) (a < b) ? a : b

struct RIFF_Header {
	char chunkID[4];
	long chunkSize;//size not including chunkSize or chunkID
	char format[4];
};

struct WAVE_Format {
	char subChunkID[4];
	long subChunkSize;
	short audioFormat;
	short numChannels;
	long sampleRate;
	long byteRate;
	short blockAlign;
	short bitsPerSample;
};

struct WAVE_Data {
	char subChunkID[4]; //should contain the word data
	long subChunk2Size; //Stores the size of the data block
};

class WAVE {
public:
	WAVE_Format wave_format;
	RIFF_Header riff_header;
	WAVE_Data wave_data;
	float** buffer;

	bool initialise(size_t stepSize, size_t blockSize);
	
	WAVE();
	~WAVE();
};
bool loadWavFile(char* filename, WAVE& output_wave);
